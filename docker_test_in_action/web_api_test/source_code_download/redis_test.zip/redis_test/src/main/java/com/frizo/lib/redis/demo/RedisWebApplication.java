package com.frizo.lib.redis.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedisWebApplication.class, args);
    }
}
