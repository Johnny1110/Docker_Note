package com.frizo.lib.redis.demo.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BaseController {

    @GetMapping("/")
    public String home(){
        return "welcome to redis web app";
    }

}
