package com.frizo.lib.redis.demo.api;

import com.frizo.lib.redis.demo.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/redis")
public class RedisController {

    @Autowired
    private RedisService redisService;

    @GetMapping("/set")
    public String setToRedis(@RequestParam("key") String key, @RequestParam("value") String data){
        redisService.set(key, data);
        return "success";
    }

    @GetMapping("/get")
    public String getValueFromRedis(@RequestParam("key") String key){
        String data = redisService.get(key);
        return data;
    }

}
