package com.frizo.docker.lib.swarm.volume.service.impl;

import com.frizo.docker.lib.swarm.volume.service.FileService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;

@Service
public class FileServiceImpl implements FileService {

    @Value("${lib.test.file.path}")
    private String theFilePath;


    @Override
    public File getTheFile() {
        File theFile = new File(theFilePath);
        return theFile;
    }

    @Override
    public String getTheFilePath() {
        return theFilePath;
    }
}
