package com.frizo.docker.lib.swarm.volume.service;

import java.io.File;

public interface FileService {

    File getTheFile();

    String getTheFilePath();

}
